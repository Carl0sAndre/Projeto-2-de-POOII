﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Model
{
    internal class Transacao
    {
        public class Transacao
        {
            public string Tipo { get; set; }
            public double Valor { get; set; }
            public DateTime Data { get; set; }
            public int ContaOrigem { get; set; }
            public int ContaDestino { get; set; }

            public Transacao(string tipo, double valor, int origem, int destino)
            {
                Tipo = tipo;
                Valor = valor;
                ContaOrigem = origem;
                ContaDestino = destino;
                Data = DateTime.Now;
            }
        }

    }
}
