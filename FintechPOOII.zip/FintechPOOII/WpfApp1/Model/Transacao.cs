﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    // Seu diagrama chama de <<interface>> Transacao
    public interface Transacao
    {
        decimal Valor { get; }
        DateTime Data { get; }
        void Executar(); // O método principal do padrão Command
    }
}
