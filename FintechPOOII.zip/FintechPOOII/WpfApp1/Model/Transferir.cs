﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WpfApp1
{
    public class Transferir : Transacao
    {
        private Conta _contaOrigem;
        private Conta _contaDestino;
        public decimal Valor { get; private set; }
        public DateTime Data { get; private set; }

        public Transferir(Conta contaOrigem, Conta contaDestino, decimal valor)
        {
            _contaOrigem = contaOrigem;
            _contaDestino = contaDestino;
            Valor = valor;
            Data = DateTime.Now;
        }

        public void Executar()
        {
            if (_contaOrigem.Sacar(Valor))
            {
                _contaDestino.Depositar(Valor);

                // Adiciona nos extratos de ambas as contas
                _contaOrigem.Extrato.Add(this);
                _contaDestino.Extrato.Add(this);
            }
            else
            {
                throw new InvalidOperationException("Saldo insuficiente para a transferência.");
            }
        }
    }
}
