﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WpfApp1
{
    public class Banco
    {
        public string Nome { get; private set; }
        public GerenciadorDeClientes Clientes { get; private set; }
        public GerenciadorDeContas Contas { get; private set; }
        public GerenciadorDeTransacoes Transacoes { get; private set; }
        public Calendario Calendario { get; private set; }

        // Construtor que inicializa todos os gerenciadores
        public Banco(string nome)
        {
            Nome = nome;
            Clientes = new GerenciadorDeClientes();
            Contas = new GerenciadorDeContas();
            Transacoes = new GerenciadorDeTransacoes();
            Calendario = new Calendario();
        }
    }
}
