﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Model
{
    internal class Conta
    {

        public List<Transacao> Historico { get; private set; } = new List<Transacao>();
        Historico.Add(new Transacao("Transferência", valor, Numero, destino.Numero));

        public abstract class Conta
        {
            private static int GeradorNumero = 1;

            public int Numero { get; private set; }
            public Cliente Cliente { get; private set; }
            public double Saldo { get; protected set; }

            public Conta(Cliente cliente)
            {
                Numero = GeradorNumero++;
                Cliente = cliente;
                Saldo = 0;
            }

            public virtual bool Depositar(double valor)
            {
                if (valor <= 0) return false;
                Saldo += valor;
                return true;
            }

            public virtual bool Sacar(double valor)
            {
                if (valor <= 0 || valor > Saldo) return false;
                Saldo -= valor;
                return true;
            }

            public bool Transferir(Conta destino, double valor)
            {
                if (Sacar(valor))
                {
                    destino.Depositar(valor);
                    return true;
                }
                return false;
            }
        }


    }
}
