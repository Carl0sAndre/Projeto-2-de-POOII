﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WpfApp1
{
    public abstract class Conta
    {
        public int ContaId { get; set; }
        public string NumeroAgencia { get; private set; }
        public string NumeroConta { get; private set; }
        public Cliente Titular { get; private set; }

        // 'protected set' permite que classes filhas (Poupanca, ContaCorrente) alterem o saldo
        public decimal Saldo { get; protected set; }

        // "envolve" Transacao - implementado como um extrato
        public List<Transacao> Extrato { get; private set; }

        protected Conta(Cliente titular, string agencia, string numero)
        {
            Titular = titular;
            NumeroAgencia = agencia;
            NumeroConta = numero;
            Saldo = 0;
            Extrato = new List<Transacao>();
        }

        // Métodos 'virtual' podem ser sobrescritos pelas classes filhas
        public virtual void Depositar(decimal valor)
        {
            if (valor <= 0)
            {
                throw new ArgumentException("O valor do depósito deve ser positivo.");
            }
            Saldo += valor;
        }

        public virtual bool Sacar(decimal valor)
        {
            if (valor <= 0)
            {
                throw new ArgumentException("O valor do saque deve ser positivo.");
            }

            if (Saldo >= valor)
            {
                Saldo -= valor;
                return true;
            }

            return false; // Saldo insuficiente
        }
    }
}
