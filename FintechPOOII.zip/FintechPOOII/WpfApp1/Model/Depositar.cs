﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Depositar : Transacao
    {
        private Conta _contaDestino;
        public decimal Valor { get; private set; }
        public DateTime Data { get; private set; }

        public Depositar(Conta contaDestino, decimal valor)
        {
            _contaDestino = contaDestino;
            Valor = valor;
            Data = DateTime.Now;
        }

        public void Executar()
        {
            _contaDestino.Depositar(Valor);
            // Adiciona ao extrato da conta específica
            _contaDestino.Extrato.Add(this);
        }
    }
}
