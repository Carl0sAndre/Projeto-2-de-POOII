﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WpfApp1
{
    public class Poupanca : Conta
    {
        public decimal TaxaRendimento { get; private set; } // Ex: 0.005 para 0.5% a.m.

        public Poupanca(Cliente titular, string agencia, string numero, decimal taxaRendimento)
            : base(titular, agencia, numero)
        {
            TaxaRendimento = taxaRendimento;
        }

        // Método específico da poupança
        public void AplicarRendimento()
        {
            decimal rendimento = Saldo * TaxaRendimento;
            Depositar(rendimento); // Reutiliza o método da classe base
        }
    }
}
