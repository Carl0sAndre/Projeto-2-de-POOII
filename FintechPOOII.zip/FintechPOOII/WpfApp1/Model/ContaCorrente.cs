﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WpfApp1
{
    public class ContaCorrente : Conta
    {
        public decimal LimiteChequeEspecial { get; set; }

        public ContaCorrente(Cliente titular, string agencia, string numero, decimal limite)
            : base(titular, agencia, numero)
        {
            LimiteChequeEspecial = limite;
        }

        // 'override' para implementar a lógica de saque com limite
        public override bool Sacar(decimal valor)
        {
            if (valor <= 0)
            {
                throw new ArgumentException("O valor do saque deve ser positivo.");
            }

            // Verifica se o saldo + limite é suficiente
            if ((Saldo + LimiteChequeEspecial) >= valor)
            {
                Saldo -= valor;
                return true;
            }

            return false; // Saldo e limite insuficientes
        }
    }
}
