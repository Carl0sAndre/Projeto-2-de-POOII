﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WpfApp1
{
    public class Cliente
    {
        public int ClienteId { get; set; } // Um ID único
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Endereco { get; set; }

        // Um cliente pode ter várias contas
        public List<Conta> Contas { get; private set; }

        public Cliente(string nome, string cpf)
        {
            Nome = nome;
            Cpf = cpf;
            Contas = new List<Conta>();
        }
    }
}
