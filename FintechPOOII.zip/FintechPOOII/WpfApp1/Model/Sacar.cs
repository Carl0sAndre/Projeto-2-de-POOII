﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WpfApp1
{
    public class Sacar : Transacao
    {
        private Conta _conta;
        public decimal Valor { get; private set; }
        public DateTime Data { get; private set; }

        public Sacar(Conta conta, decimal valor)
        {
            _conta = conta;
            Valor = valor;
            Data = DateTime.Now;
        }

        public void Executar()
        {
            if (_conta.Sacar(Valor))
            {
                // Adiciona ao extrato da conta específica
                _conta.Extrato.Add(this);
            }
            else
            {
                // Lança uma exceção que o GerenciadorDeTransacoes vai pegar
                throw new InvalidOperationException("Saldo insuficiente para o saque.");
            }
        }
    }
}