﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.Controller
{
    internal class GerenciadorDeClientes
    {
        public class GerenciadorDeClientes
        {
            private List<Cliente> clientes = new List<Cliente>();

            public Cliente CadastrarCliente(string nome, string cpf)
            {
                var cliente = new Cliente(nome, cpf);
                clientes.Add(cliente);
                return cliente;
            }

            public Cliente BuscarPorCpf(string cpf)
            {
                return clientes.Find(c => c.CPF == cpf);
            }

            public List<Cliente> ListarClientes()
            {
                return clientes;
            }
        }
    }
}
