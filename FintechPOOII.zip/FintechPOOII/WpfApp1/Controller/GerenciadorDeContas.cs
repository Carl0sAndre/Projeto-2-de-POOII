﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.Controller
{
    internal class GerenciadorDeContas
    {
        public class GerenciadorDeContas
        {
            private List<Conta> contas = new List<Conta>();

            public Conta CriarConta(Cliente cliente, string tipoConta)
            {
                Conta conta;

                if (tipoConta == "Corrente")
                    conta = new ContaCorrente(cliente);
                else
                    conta = new Poupanca(cliente);

                contas.Add(conta);
                return conta;
            }

            public Conta BuscarPorNumero(int numero)
            {
                return contas.Find(c => c.Numero == numero);
            }

            public List<Conta> ListarContas()
            {
                return contas;
            }
        }
    }
}
