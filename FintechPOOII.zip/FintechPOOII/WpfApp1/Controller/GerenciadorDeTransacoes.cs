﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Controller
{
    internal class GerenciadorDeTransacoes
    {
        public class GerenciadorDeTransacoes
        {
            public bool Depositar(Conta conta, double valor)
            {
                return conta.Depositar(valor);
            }

            public bool Sacar(Conta conta, double valor)
            {
                return conta.Sacar(valor);
            }

            public bool Transferir(Conta origem, Conta destino, double valor)
            {
                return origem.Transferir(destino, valor);
            }
        }
    }
}
